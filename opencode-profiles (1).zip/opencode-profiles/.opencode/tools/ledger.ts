import { tool } from "@opencode-ai/plugin"
import { appendJsonl, benchPath, downstream, foldLedger, ledgerMdPath, ledgerPath, loadConfig, loadOutcomes, now, readJsonl, readyTasks, renderLedger, route, tierGuard, writeText } from "../lib/core"

const STATUS = ["pending", "running", "verifying", "done", "failed", "blocked", "split", "dropped"] as const
const VERIFY = ["V1", "V2", "V3", "V4"] as const

export default tool({
  description:
    "Project task ledger for the research profile (append-only log; rendered to research/LEDGER.md). Only the orchestrator calls this. " +
    "Actions: add (register tasks), update (status, tier, difficulty, priority, verification level, note), " +
    "ready (tasks whose dependencies are done, best first, each with a recommended starting tier), view (re-render). " +
    "Setting status=failed records the current tier as failed. Tier astra is refused unless the task is priority 1 and sol has failed on it.",
  args: {
    action: tool.schema.enum(["add", "update", "ready", "view"]).describe("What to do"),
    tasks: tool.schema
      .array(
        tool.schema.object({
          id: tool.schema.string().optional().describe("Task id such as T001. Omit to auto-assign."),
          title: tool.schema.string().describe("One specific line; used to find similar past tasks"),
          type: tool.schema.string().describe("framing | explore | lookup | literature | derivation | numerics | code | data_analysis | design | writing | verification | other"),
          difficulty: tool.schema.number().int().min(1).max(5).describe("1 trivial ... 5 hardest, per the difficulty rubric in the research-planning skill"),
          priority: tool.schema.number().int().min(1).max(3).optional().describe("1 = the goal's conclusion depends on it, 2 = normal (default), 3 = nice to have"),
          verify: tool.schema.enum(VERIFY).optional().describe("Verification level per the research-verification skill (default V1)"),
          deps: tool.schema.array(tool.schema.string()).optional().describe("Ids that must be done first"),
          card: tool.schema.string().optional().describe("Path to the task card"),
          link: tool.schema.string().optional().describe("Which hypothesis or sub-question this serves, in a few words"),
        }),
      )
      .optional()
      .describe("For action=add"),
    id: tool.schema.string().optional().describe("For action=update"),
    status: tool.schema.enum(STATUS).optional(),
    tier: tool.schema.enum(["luna", "terra", "sol", "astra"]).optional().describe("Tier the task is (re)assigned to"),
    difficulty: tool.schema.number().int().min(1).max(5).optional().describe("Re-grade, if the task turned out different"),
    priority: tool.schema.number().int().min(1).max(3).optional(),
    verify: tool.schema.enum(VERIFY).optional(),
    note: tool.schema.string().optional().describe("Short note, e.g. why it failed or what was learned. Required when raising priority to 1."),
  },
  async execute(a, ctx) {
    const dir = ctx.directory
    const events = () => readJsonl(ledgerPath(dir))
    const save = () => {
      const tasks = foldLedger(events())
      writeText(ledgerMdPath(dir), renderLedger(tasks))
      return tasks
    }

    if (a.action === "add") {
      if (!a.tasks?.length) return "ERROR: action=add needs `tasks`."
      const tasks = foldLedger(events())
      let n = tasks.size
      const ids: string[] = []
      for (const t of a.tasks) {
        const id = t.id ?? `T${String(++n).padStart(3, "0")}`
        if (tasks.has(id)) return `ERROR: task ${id} already exists. Use update.`
        appendJsonl(ledgerPath(dir), { t: now(), op: "add", ...t, id })
        tasks.set(id, { id } as any)
        ids.push(id)
      }
      const all = save()
      const unknown = a.tasks.flatMap((t) => (t.deps ?? []).filter((d) => !all.has(d)))
      return `Added ${ids.join(", ")}.` + (unknown.length ? ` WARNING: unknown deps: ${[...new Set(unknown)].join(", ")}` : "")
    }

    if (a.action === "update") {
      if (!a.id) return "ERROR: action=update needs `id`."
      const cur = foldLedger(events()).get(a.id)
      if (!cur) return `ERROR: unknown task ${a.id}.`
      if (a.priority === 1 && cur.priority !== 1 && !a.note) return "ERROR: raising priority to 1 needs a note saying why the conclusion depends on this task."
      if (a.tier) {
        const why = tierGuard({ ...cur, priority: a.priority ?? cur.priority }, a.tier)
        if (why) return `REFUSED: ${why}`
      }
      appendJsonl(ledgerPath(dir), { t: now(), op: "update", id: a.id, status: a.status, tier: a.tier, difficulty: a.difficulty, priority: a.priority, verify: a.verify, note: a.note })
      const t = save().get(a.id)!
      return `${t.id}: ${t.status}${t.tier ? ` @${t.tier}` : ""} P${t.priority} ${t.verify}${t.failedTiers.length ? ` (failed: ${t.failedTiers.join(",")})` : ""}`
    }

    if (a.action === "ready") {
      const tasks = foldLedger(events())
      const cfg = loadConfig(dir)
      const outs = loadOutcomes(benchPath())
      const ds = downstream(tasks)
      const ready = readyTasks(tasks)
      const busy = [...tasks.values()].filter((t) => t.status === "running" || t.status === "verifying")
      if (!ready.length) return `No ready tasks. Running/verifying: ${busy.map((t) => t.id).join(", ") || "none"}. Pending: ${[...tasks.values()].filter((t) => t.status === "pending").length}.`
      const lines = ready.map((t) => {
        const r = route(outs, t.type, t.difficulty, cfg, { priority: t.priority, depth: ds.get(t.id)!.depth })
        return `${t.id} | P${t.priority} ${t.type} d${t.difficulty} ${t.verify} | waits-on-it depth ${ds.get(t.id)!.depth} | start at ${r.recommended} (evidence: ${r.evidence}) | ${t.card ?? "no card"} | ${t.title}`
      })
      return [`Running/verifying now: ${busy.length}. Ready (best first):`, ...lines].join("\n")
    }

    return renderLedger(save())
  },
})
