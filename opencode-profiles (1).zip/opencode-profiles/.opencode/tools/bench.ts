import { tool } from "@opencode-ai/plugin"
import { appendJsonl, benchPath, loadConfig, loadOutcomes, now, project, report, route, similar } from "../lib/core"

const TIERS = ["luna", "terra", "sol", "astra"] as const

export default tool({
  description:
    "Local benchmark of model tiers (luna/terra/sol/astra) on your own tasks. Stored globally, shared across projects. Only orchestrators call this. " +
    "Actions: outcome (log one verified attempt), route (recommend a starting tier), similar (past tasks with realised difficulty, to anchor grading), " +
    "report (first-try allocation, pass rates, grading calibration, verifier reliability), " +
    "label (later evidence about a past result: from the user, a blind replication, a downstream task, or the integration check; overrides the verifier).",
  args: {
    action: tool.schema.enum(["outcome", "route", "similar", "report", "label"]),
    task_id: tool.schema.string().optional(),
    title: tool.schema.string().optional().describe("Task title (outcome) or free-text query (similar)"),
    type: tool.schema.string().optional(),
    difficulty: tool.schema.number().int().min(1).max(5).optional().describe("Difficulty as assigned BEFORE the first attempt; keep it fixed across escalations"),
    priority: tool.schema.number().int().min(1).max(3).optional(),
    depth: tool.schema.number().int().min(1).optional().describe("For route: how long a chain of tasks waits on this one (1 = none)"),
    tier: tool.schema.enum(TIERS).optional().describe("Tier that did the attempt"),
    attempt: tool.schema.number().int().min(1).optional().describe("1 for the first attempt, 2 after the first escalation, ..."),
    verdict: tool.schema.enum(["pass", "pass_with_issues", "fail", "incomplete", "wrong_question"]).optional().describe("Verifier's verdict, never the worker's self-report"),
    verify_level: tool.schema.enum(["V1", "V2", "V3", "V4"]).optional(),
    verifier_tier: tool.schema.string().optional(),
    steps: tool.schema.number().optional(),
    seconds: tool.schema.number().optional().describe("Wall-clock seconds from launch to report, if you can tell"),
    tokens: tool.schema.number().optional(),
    cost: tool.schema.number().optional().describe("Real cost if known; otherwise the relative weight in tiers.json is used"),
    note: tool.schema.string().optional(),
    label: tool.schema.enum(["good", "bad"]).optional().describe("For action=label"),
    source: tool.schema.enum(["human", "replication", "downstream", "integration"]).optional().describe("For action=label: where the later evidence came from (default human)"),
    low_stakes: tool.schema.boolean().optional().describe("For route: cheap to redo and easy to verify, so occasional exploration of a cheaper tier is allowed"),
  },
  async execute(a, ctx) {
    const dir = ctx.directory
    const cfg = loadConfig(dir)
    const proj = project(dir)

    if (a.action === "outcome") {
      for (const k of ["task_id", "type", "difficulty", "tier", "verdict"] as const)
        if (a[k] === undefined) return `ERROR: outcome needs ${k}.`
      appendJsonl(benchPath(), {
        kind: "outcome", t: now(), project: proj, task_id: a.task_id, title: a.title, type: a.type, difficulty: a.difficulty, priority: a.priority,
        tier: a.tier, attempt: a.attempt ?? 1, verdict: a.verdict, verify_level: a.verify_level, verifier_tier: a.verifier_tier, steps: a.steps,
        seconds: a.seconds, tokens: a.tokens, cost: a.cost, note: a.note,
      })
      return `Logged ${a.task_id} ${a.tier} d${a.difficulty} attempt ${a.attempt ?? 1}: ${a.verdict}.`
    }

    if (a.action === "label") {
      if (!a.task_id || !a.label) return "ERROR: label needs task_id and label."
      appendJsonl(benchPath(), { kind: "label", t: now(), project: proj, task_id: a.task_id, tier: a.tier, label: a.label, source: a.source ?? "human" })
      return `Labelled ${a.task_id} ${a.label} (source: ${a.source ?? "human"}).`
    }

    const outs = loadOutcomes(benchPath())
    if (a.action === "route") {
      if (!a.type || !a.difficulty) return "ERROR: route needs type and difficulty."
      return JSON.stringify(route(outs, a.type, a.difficulty, cfg, { priority: a.priority, depth: a.depth, lowStakes: a.low_stakes }), null, 2)
    }
    if (a.action === "similar") {
      if (!a.title) return "ERROR: similar needs `title` as the query."
      const r = similar(outs, a.title, a.type)
      return r.length ? JSON.stringify(r, null, 2) : "No similar past tasks yet."
    }
    return report(outs, cfg)
  },
})
