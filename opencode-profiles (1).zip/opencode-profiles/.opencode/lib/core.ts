// Shared logic for the `ledger` and `bench` tools. Pure functions + tiny JSONL helpers.
// Lives in .opencode/lib/ (not tools/) so opencode does not register it as a tool.
import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs"
import { homedir } from "node:os"
import { basename, dirname, join } from "node:path"

/** Full escalation ladder. Only STARTABLE tiers can be a first attempt; astra is reached by escalation only. */
export const LADDER = ["luna", "terra", "sol", "astra"] as const
export type Tier = (typeof LADDER)[number]
export const STARTABLE: Tier[] = ["luna", "terra", "sol"]

// ---------- config ----------
export interface Config {
  cost: Record<Tier, number> // relative money cost of one attempt
  latency: Record<Tier, number> // relative wall-clock time of one attempt
  verify_cost: number
  verify_latency: number // time per attempt spent on verification and the orchestrator round, paid again on every failure
  rescope_cost: number // cost when the ladder is exhausted and the orchestrator must re-scope, split or drop
  time_weight: number // money units per latency unit, for a task nothing waits on
  prior_cap: Record<Tier, number> // highest difficulty a tier is expected to handle (prior only)
  prior_strength: number // pseudo-observations behind the prior
  explore_rate: number
  explore_min_n: number
}
export const DEFAULTS: Config = {
  cost: { luna: 1, terra: 4, sol: 15, astra: 60 },
  latency: { luna: 2, terra: 2.5, sol: 4, astra: 6 },
  verify_cost: 1,
  verify_latency: 1.5,
  rescope_cost: 30,
  time_weight: 1,
  prior_cap: { luna: 2, terra: 3, sol: 4, astra: 5 },
  prior_strength: 2,
  explore_rate: 0.15,
  explore_min_n: 5,
}
export function loadConfig(dir: string): Config {
  for (const p of [join(dir, ".opencode/kit/tiers.json"), join(homedir(), ".config/opencode/kit/tiers.json")]) {
    if (!existsSync(p)) continue
    try {
      const c = JSON.parse(readFileSync(p, "utf8"))
      return {
        ...DEFAULTS,
        ...c,
        cost: { ...DEFAULTS.cost, ...c.cost },
        latency: { ...DEFAULTS.latency, ...c.latency },
        prior_cap: { ...DEFAULTS.prior_cap, ...c.prior_cap },
      }
    } catch {
      /* fall through to defaults */
    }
  }
  return DEFAULTS
}

// ---------- jsonl ----------
export function readJsonl<T = any>(p: string): T[] {
  if (!existsSync(p)) return []
  const out: T[] = []
  for (const line of readFileSync(p, "utf8").split("\n")) {
    if (!line.trim()) continue
    try {
      out.push(JSON.parse(line))
    } catch {
      /* skip a corrupt line rather than lose the log */
    }
  }
  return out
}
export function appendJsonl(p: string, obj: unknown) {
  mkdirSync(dirname(p), { recursive: true })
  appendFileSync(p, JSON.stringify(obj) + "\n")
}
export function writeText(p: string, s: string) {
  mkdirSync(dirname(p), { recursive: true })
  writeFileSync(p, s)
}
export const now = () => new Date().toISOString()
export const project = (dir: string) => basename(dir)
export const benchPath = () =>
  join(process.env.OPENCODE_BENCH_DIR ?? join(homedir(), ".local/share/opencode-bench"), "events.jsonl")
export const ledgerPath = (dir: string) => join(dir, "research/ledger.jsonl")
export const ledgerMdPath = (dir: string) => join(dir, "research/LEDGER.md")

// ---------- ledger (task graph) ----------
export type Status = "pending" | "running" | "verifying" | "done" | "failed" | "blocked" | "split" | "dropped"
export type VerifyLevel = "V1" | "V2" | "V3" | "V4"
export interface Task {
  id: string
  title: string
  type: string
  difficulty: number
  priority: number // 1 = load-bearing / on the main line of the goal, 2 = normal, 3 = nice to have
  verify: VerifyLevel
  deps: string[]
  status: Status
  tier?: Tier
  failedTiers: Tier[]
  card?: string
  link?: string
  notes: string[]
  created: string
  updated: string
}

export function foldLedger(events: any[]): Map<string, Task> {
  const m = new Map<string, Task>()
  for (const e of events) {
    if (e.op === "add") {
      m.set(e.id, {
        id: e.id,
        title: e.title ?? e.id,
        type: e.type ?? "other",
        difficulty: e.difficulty ?? 3,
        priority: e.priority ?? 2,
        verify: e.verify ?? "V1",
        deps: e.deps ?? [],
        status: "pending",
        failedTiers: [],
        card: e.card,
        link: e.link,
        notes: [],
        created: e.t,
        updated: e.t,
      })
    } else if (e.op === "update") {
      const t = m.get(e.id)
      if (!t) continue
      if (e.tier) t.tier = e.tier
      if (e.status) {
        t.status = e.status
        if (e.status === "failed" && t.tier && !t.failedTiers.includes(t.tier)) t.failedTiers.push(t.tier)
      }
      if (e.difficulty) t.difficulty = e.difficulty
      if (e.priority) t.priority = e.priority
      if (e.verify) t.verify = e.verify
      if (e.note) t.notes.push(`${String(e.t).slice(0, 16)} ${e.note}`)
      t.updated = e.t
    }
  }
  return m
}

/** Why a tier assignment is not allowed, or null if it is. Astra is escalation-only and only for priority-1 work. */
export function tierGuard(t: Task, tier: Tier): string | null {
  if (tier !== "astra") return null
  if (t.priority !== 1) return `astra is reserved for priority-1 tasks; ${t.id} is priority ${t.priority}. Re-scope, split or drop instead, or raise the priority with a note explaining why it is load-bearing.`
  if (!t.failedTiers.includes("sol")) return `astra is escalation-only: ${t.id} has no verified sol failure yet (failed tiers: ${t.failedTiers.join(", ") || "none"}).`
  return null
}

/** depth = longest chain of tasks that wait on this one (1 = nothing waits); unlocks = all transitive dependents. */
export function downstream(tasks: Map<string, Task>) {
  const kids = new Map<string, string[]>()
  for (const t of tasks.values()) for (const d of t.deps) kids.set(d, [...(kids.get(d) ?? []), t.id])
  const memo = new Map<string, number>()
  const depthOf = (id: string, stack: Set<string>): number => {
    if (memo.has(id)) return memo.get(id)!
    if (stack.has(id)) return 0 // cycle guard
    stack.add(id)
    const v = 1 + Math.max(0, ...(kids.get(id) ?? []).map((k) => depthOf(k, stack)))
    stack.delete(id)
    memo.set(id, v)
    return v
  }
  const out = new Map<string, { depth: number; unlocks: number }>()
  for (const id of tasks.keys()) {
    const seen = new Set<string>()
    const q = [...(kids.get(id) ?? [])]
    while (q.length) {
      const k = q.pop()!
      if (seen.has(k)) continue
      seen.add(k)
      q.push(...(kids.get(k) ?? []))
    }
    out.set(id, { depth: depthOf(id, new Set()), unlocks: seen.size })
  }
  return out
}

export function readyTasks(tasks: Map<string, Task>): Task[] {
  const ds = downstream(tasks)
  return [...tasks.values()]
    .filter((t) => t.status === "pending" && t.deps.every((d) => tasks.get(d)?.status === "done"))
    .sort((a, b) => {
      const A = ds.get(a.id)!, B = ds.get(b.id)!
      return a.priority - b.priority || B.depth - A.depth || B.unlocks - A.unlocks || a.difficulty - b.difficulty
    })
}

/** Time pressure: a failed attempt on a task many others wait on delays all of them. */
export function urgency(depth: number, priority: number) {
  return Math.min(4, 1 + 0.5 * (depth - 1)) * (priority === 1 ? 1.5 : 1)
}

export function renderLedger(tasks: Map<string, Task>): string {
  const ready = new Set(readyTasks(tasks).map((t) => t.id))
  const order: Status[] = ["running", "verifying", "pending", "blocked", "failed", "done", "split", "dropped"]
  const counts = order.map((s) => `${s}: ${[...tasks.values()].filter((t) => t.status === s).length}`).join(" | ")
  const rows = [...tasks.values()]
    .sort((a, b) => order.indexOf(a.status) - order.indexOf(b.status) || a.id.localeCompare(b.id))
    .map(
      (t) =>
        `| ${t.id} | ${t.status}${ready.has(t.id) ? " (ready)" : ""} | P${t.priority} | ${t.type} | ${t.difficulty} | ${t.verify} | ${t.tier ?? ""}${t.failedTiers.length ? ` (failed: ${t.failedTiers.join(",")})` : ""} | ${t.deps.join(", ")} | ${t.title.replace(/\|/g, "/")} | ${t.notes.at(-1)?.replace(/\|/g, "/") ?? ""} |`,
    )
  return [
    "# Task ledger (generated from ledger.jsonl; do not edit by hand)",
    "",
    counts,
    "",
    "| id | status | prio | type | diff | verify | tier | deps | title | last note |",
    "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ...rows,
    "",
  ].join("\n")
}

// ---------- benchmark ----------
export type Verdict = "pass" | "pass_with_issues" | "fail" | "incomplete" | "wrong_question"
export interface Outcome {
  kind: "outcome"
  t: string
  project: string
  task_id: string
  title?: string
  type: string
  difficulty: number
  priority?: number
  tier: Tier
  attempt: number
  verdict: Verdict
  verify_level?: VerifyLevel
  verifier_tier?: string
  steps?: number
  seconds?: number
  tokens?: number
  cost?: number
  note?: string
  label?: "good" | "bad"
  labelSource?: LabelSource
}
export type LabelSource = "human" | "replication" | "downstream" | "integration"
export interface Label {
  kind: "label"
  t: string
  project: string
  task_id: string
  tier?: Tier
  label: "good" | "bad"
  source?: LabelSource
}

export function loadOutcomes(path: string): Outcome[] {
  const ev = readJsonl<any>(path)
  const outs: Outcome[] = ev.filter((e) => e.kind === "outcome")
  const rank: Record<LabelSource, number> = { integration: 1, downstream: 2, replication: 3, human: 4 }
  for (const l of ev.filter((e) => e.kind === "label") as Label[])
    for (const o of outs)
      if (o.project === l.project && o.task_id === l.task_id && (!l.tier || o.tier === l.tier)) {
        const src = l.source ?? "human"
        if (!o.labelSource || rank[src] >= rank[o.labelSource]) {
          o.label = l.label
          o.labelSource = src
        }
      }
  return outs
}

const verifierPassed = (o: Outcome) => o.verdict === "pass" || o.verdict === "pass_with_issues"

/** 1 = success, 0 = failure, null = says nothing about the tier. Later evidence (labels) overrides the verifier. */
export function effective(o: Outcome): 1 | 0 | null {
  if (o.verdict === "wrong_question") return null
  if (o.label === "good") return 1
  if (o.label === "bad") return 0
  return verifierPassed(o) ? 1 : 0
}

function prior(tier: Tier, d: number, cfg: Config) {
  const cap = cfg.prior_cap[tier]
  return d <= cap ? 0.85 : d === cap + 1 ? 0.2 : 0.05
}

export function cell(outs: Outcome[], tier: Tier, type: string, d: number, cfg: Config) {
  let s = 0, f = 0, nExact = 0
  for (const o of outs) {
    if (o.tier !== tier) continue
    const e = effective(o)
    if (e === null) continue
    let w = 0
    if (o.type === type && o.difficulty === d) w = 1
    else if (o.difficulty === d) w = 0.4 // same difficulty, other type
    else if (o.type === type && Math.abs(o.difficulty - d) === 1) w = 0.25 // same type, adjacent difficulty
    if (!w) continue
    if (w === 1) nExact++
    e ? (s += w) : (f += w)
  }
  const p0 = prior(tier, d, cfg)
  const a = cfg.prior_strength * p0 + s
  const b = cfg.prior_strength * (1 - p0) + f
  const p = a / (a + b)
  const sd = Math.sqrt((a * b) / ((a + b) ** 2 * (a + b + 1)))
  return { p, lcb: Math.max(0, p - 0.84 * sd), nExact, nEff: s + f }
}

export interface RouteOpts {
  priority?: number
  depth?: number
  lowStakes?: boolean
  rnd?: () => number
}

/**
 * Expected cost of starting at each startable tier, escalating one tier per failure.
 * E_i = c_i + v + w*(lat_i + lat_v) + (1 - p_i) * E_{i+1}. Past sol: astra if priority 1, otherwise a re-scope.
 * w = time_weight * urgency, so on the critical path a wasted cheap attempt costs real time.
 */
export function route(outs: Outcome[], type: string, d: number, cfg: Config, o: RouteOpts = {}) {
  const priority = o.priority ?? 2
  const depth = o.depth ?? 1
  const w = cfg.time_weight * urgency(depth, priority)
  const ladder: Tier[] = priority === 1 ? [...LADDER] : STARTABLE
  const cells = ladder.map((tier) => ({ tier, ...cell(outs, tier, type, d, cfg) }))
  const E: number[] = []
  for (let i = ladder.length - 1; i >= 0; i--) {
    const next = i === ladder.length - 1 ? cfg.rescope_cost : E[i + 1]
    E[i] = cfg.cost[ladder[i]] + cfg.verify_cost + w * (cfg.latency[ladder[i]] + cfg.verify_latency) + (1 - cells[i].p) * next
  }
  let best = 0
  for (let i = 1; i < STARTABLE.length; i++) if (E[i] < E[best]) best = i
  let pick = best
  let explore = false
  const rnd = o.rnd ?? Math.random
  // Explore one tier cheaper only where a wasted attempt is cheap in money AND time.
  if (o.lowStakes && priority > 1 && depth <= 1 && best > 0 && cells[best - 1].nExact < cfg.explore_min_n && rnd() < cfg.explore_rate) {
    pick = best - 1
    explore = true
  }
  const n = cells[best].nExact
  return {
    recommended: ladder[pick],
    explore,
    evidence: n >= 10 ? "rich" : n >= 3 ? "ok" : "thin (mostly prior)",
    urgency: +urgency(depth, priority).toFixed(2),
    table: cells.map((c, i) => ({
      tier: c.tier,
      startable: STARTABLE.includes(c.tier),
      p_pass: +c.p.toFixed(2),
      p_lower: +c.lcb.toFixed(2),
      n_exact: c.nExact,
      expected_cost_if_start_here: +E[i].toFixed(1),
    })),
  }
}

export interface TaskResult {
  key: string
  title?: string
  type: string
  assigned: number
  startTier: Tier
  minTier: Tier | null
  exact: boolean // true if the next-lower tier was tried and failed (or minTier is luna)
  escalations: number
  wastedCost: number
  wastedSeconds: number
}
export function taskResults(outs: Outcome[], cfg: Config = DEFAULTS): TaskResult[] {
  const by = new Map<string, Outcome[]>()
  for (const o of outs) by.set(`${o.project}/${o.task_id}`, [...(by.get(`${o.project}/${o.task_id}`) ?? []), o])
  const res: TaskResult[] = []
  for (const [key, list] of by) {
    list.sort((a, b) => a.attempt - b.attempt)
    const first = list[0]
    const solvedIdx = list.findIndex((o) => effective(o) === 1)
    const failedBefore = solvedIdx < 0 ? list : list.slice(0, solvedIdx)
    const wastedCost = failedBefore.reduce((a, o) => a + (o.cost ?? cfg.cost[o.tier]), 0)
    const wastedSeconds = failedBefore.reduce((a, o) => a + (o.seconds ?? 0), 0)
    const solved = list.filter((o) => effective(o) === 1).map((o) => LADDER.indexOf(o.tier))
    const base = { key, title: first.title, type: first.type, assigned: first.difficulty, startTier: first.tier, escalations: failedBefore.filter((o) => effective(o) === 0).length, wastedCost, wastedSeconds }
    if (!solved.length) {
      res.push({ ...base, minTier: null, exact: false })
      continue
    }
    const lo = Math.min(...solved)
    const lowerFailed = list.some((o) => LADDER.indexOf(o.tier) === lo - 1 && effective(o) === 0)
    res.push({ ...base, minTier: LADDER[lo], exact: lo === 0 || lowerFailed })
  }
  return res
}

const tok = (s: string) => new Set(s.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2))
export function similar(outs: Outcome[], query: string, type: string | undefined, k = 5) {
  const q = tok(query)
  return taskResults(outs)
    .filter((r) => r.title && (!type || r.type === type))
    .map((r) => {
      const t = tok(r.title!)
      const inter = [...q].filter((w) => t.has(w)).length
      return { r, score: inter / Math.max(1, q.size + t.size - inter) }
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, k)
    .map(({ r, score }) => ({ title: r.title, type: r.type, assigned: r.assigned, started_at: r.startTier, lowest_passing: r.minTier ?? "unsolved", exact: r.exact, similarity: +score.toFixed(2) }))
}

const pct = (x: number) => (Number.isFinite(x) ? `${Math.round(x * 100)}%` : "-")
const avg = (xs: number[]) => (xs.length ? (xs.reduce((a, b) => a + b, 0) / xs.length).toFixed(1) : "-")

export function report(outs: Outcome[], cfg: Config): string {
  if (!outs.length) return "No outcomes logged yet."
  const tr = taskResults(outs, cfg)
  const L: string[] = [`# Benchmark report (${outs.length} attempts, ${tr.length} tasks)`, ""]

  // 1. First-try allocation: the number the user cares about most.
  const solved = tr.filter((r) => r.minTier)
  const hit = tr.filter((r) => r.escalations === 0 && r.minTier)
  const exactHit = hit.filter((r) => r.exact && r.minTier === r.startTier)
  const wasted = tr.reduce((a, r) => a + r.wastedCost, 0)
  const spent = outs.reduce((a, o) => a + (o.cost ?? cfg.cost[o.tier]), 0)
  L.push("## First-try allocation", "",
    `- Solved at the first tier tried: ${hit.length}/${tr.length} (${pct(hit.length / tr.length)}).`,
    `- Of those, provably the cheapest sufficient tier (luna, or a lower tier failed on that task): ${exactHit.length}. The rest may have been over-allocated; only exploration can tell.`,
    `- Needed escalation: ${tr.filter((r) => r.escalations > 0).length}; average escalations when it happened: ${avg(tr.filter((r) => r.escalations > 0).map((r) => r.escalations))}.`,
    `- Spend on failed attempts: ${wasted.toFixed(0)} of ${spent.toFixed(0)} relative units (${pct(wasted / spent)}); time lost to failed attempts: ${tr.reduce((a, r) => a + r.wastedSeconds, 0).toFixed(0)} s (where logged).`,
    `- Unsolved: ${tr.length - solved.length}.`, "")
  L.push("| started at | tasks | first-try pass | escalated | unsolved |", "| --- | --- | --- | --- | --- |")
  for (const t of STARTABLE) {
    const xs = tr.filter((r) => r.startTier === t)
    if (!xs.length) continue
    L.push(`| ${t} | ${xs.length} | ${pct(xs.filter((r) => r.escalations === 0 && r.minTier).length / xs.length)} | ${xs.filter((r) => r.escalations > 0).length} | ${xs.filter((r) => !r.minTier).length} |`)
  }

  // 2. Pass rates.
  L.push("", "## Pass rate by tier and assigned difficulty", "", "| tier | diff | n | pass | avg steps | avg sec | cost / success |", "| --- | --- | --- | --- | --- | --- | --- |")
  for (const tier of LADDER)
    for (let d = 1; d <= 5; d++) {
      const xs = outs.filter((o) => o.tier === tier && o.difficulty === d && effective(o) !== null)
      if (!xs.length) continue
      const wins = xs.filter((o) => effective(o) === 1).length
      const sp = xs.reduce((a, o) => a + (o.cost ?? cfg.cost[tier]), 0)
      L.push(`| ${tier} | ${d} | ${xs.length} | ${pct(wins / xs.length)} | ${avg(xs.map((o) => o.steps ?? NaN).filter(Number.isFinite))} | ${avg(xs.map((o) => o.seconds ?? NaN).filter(Number.isFinite))} | ${wins ? (sp / wins).toFixed(1) : "-"} |`)
    }

  // 3. Grading calibration.
  L.push("", "## Grading calibration: lowest passing tier vs assigned difficulty", "",
    "Exact = the lower tier was tried and failed on that task (or luna passed). Upper bound = passed at the tier tried, cheaper tier never tried.", "",
    "| assigned | exact: luna | exact: terra | exact: sol | exact: astra | upper bound only | unsolved |", "| --- | --- | --- | --- | --- | --- | --- |")
  for (let d = 1; d <= 5; d++) {
    const xs = tr.filter((r) => r.assigned === d)
    if (!xs.length) continue
    const c = (t: Tier) => xs.filter((r) => r.exact && r.minTier === t).length
    L.push(`| ${d} | ${c("luna")} | ${c("terra")} | ${c("sol")} | ${c("astra")} | ${xs.filter((r) => r.minTier && !r.exact).length} | ${xs.filter((r) => !r.minTier).length} |`)
  }

  // 4. Verifier reliability, by the source of the later evidence.
  const labelled = outs.filter((o) => o.label && o.verdict !== "wrong_question")
  if (labelled.length) {
    L.push("", "## Verifier reliability", "", "Each later verdict (yours, a blind replication, a downstream task that relied on it, or the integration check) is compared with the verifier's verdict.", "",
      "| evidence source | n | agree | verifier passed, later found bad | verifier failed, later found good |", "| --- | --- | --- | --- | --- |")
    for (const src of ["human", "replication", "downstream", "integration"] as LabelSource[]) {
      const xs = labelled.filter((o) => o.labelSource === src)
      if (!xs.length) continue
      const agree = xs.filter((o) => (o.label === "good") === verifierPassed(o)).length
      L.push(`| ${src} | ${xs.length} | ${pct(agree / xs.length)} | ${xs.filter((o) => verifierPassed(o) && o.label === "bad").length} | ${xs.filter((o) => !verifierPassed(o) && o.label === "good").length} |`)
    }
    const byLevel = (["V1", "V2", "V3", "V4"] as VerifyLevel[]).map((v) => {
      const xs = labelled.filter((o) => (o.verify_level ?? "V1") === v && verifierPassed(o))
      return xs.length ? `${v}: ${xs.filter((o) => o.label === "bad").length}/${xs.length} false passes` : ""
    }).filter(Boolean)
    if (byLevel.length) L.push("", `False passes by verification level: ${byLevel.join("; ")}.`)
  }
  const wq = outs.filter((o) => o.verdict === "wrong_question").length
  if (wq) L.push("", "## Framing flags", "", `${wq} attempts ended in WRONG_QUESTION; review them in the ledger notes.`)
  return L.join("\n")
}
