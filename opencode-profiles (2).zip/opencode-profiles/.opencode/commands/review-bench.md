---
description: "Benchmark the reviewers on a document you trust: plant known errors and traps, review it blind, score per model. Usage: /review-bench <path> [slug] [depth=standard]"
agent: review
---

Benchmark request: $ARGUMENTS

1. Launch `rv-planter` with the document path and the slug (default: `bench-` plus the file name). Do not read anything under `review/<slug>/bench/`.
2. Run your normal procedure on the planted copy in `review/<slug>/target/`, logging checks and findings as usual. Run the benchmark probes regardless of data mode.
3. After `REPORT.md`, launch `rv-scorer` for the slug.
4. Finish with `bench review_report` and a five-line summary of what it shows.
