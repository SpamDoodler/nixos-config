---
description: "Show the local model benchmark, or record your own verdict. Usage: /bench  or  /bench label <task_id> good|bad [tier]"
agent: research
---

Arguments: $ARGUMENTS

If the arguments start with `label`, call the `bench` tool with action `label` and the task id, label and optional tier given, then confirm in one line.

Otherwise call `bench` with action `report` and summarise it in at most 10 lines: where cheaper tiers are doing well, where the grading rubric is miscalibrated (assigned difficulty versus lowest passing tier), whether the verifier and my labels agree, and one concrete change to the rubric or `tiers.json` that the data supports. Say plainly where the data is too thin to conclude anything.
