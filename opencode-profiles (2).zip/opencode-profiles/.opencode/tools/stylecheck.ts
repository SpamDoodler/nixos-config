import { tool } from "@opencode-ai/plugin"
import { readFileSync, existsSync } from "node:fs"
import { isAbsolute, join, relative } from "node:path"
import { appendJsonl, now } from "../lib/core"
import { analyse, render, type Genre } from "../lib/style"

export default tool({
  description:
    "Deterministic prose check for Markdown or LaTeX drafts: hedges, stacked hedges, stock 'AI' phrases and self-praise, signposting, vague 'this', " +
    "sentences that start with a symbol, inline-math density, sentence length, em dashes, bullets, paragraph uniformity. Limits depend on the genre. " +
    "Returns a table and line-numbered flags. With `slug`, appends the metrics to writing/<slug>/lint-history.jsonl so revisions can be compared.",
  args: {
    path: tool.schema.string().describe("File to check (.md or .tex)"),
    genre: tool.schema.enum(["physics-paper", "math-paper", "lecture-notes", "report"]).describe("Sets the limits"),
    slug: tool.schema.string().optional().describe("Writing project slug, to log the result"),
    max_flags: tool.schema.number().int().min(0).max(200).optional().describe("Flags to show (default 30)"),
  },
  async execute(a, ctx) {
    const p = isAbsolute(a.path) ? a.path : join(ctx.directory, a.path)
    if (!existsSync(p)) return `ERROR: ${a.path} not found.`
    const kind = p.endsWith(".tex") ? "tex" : "md"
    const r = analyse(readFileSync(p, "utf8"), kind, a.genre as Genre)
    if (a.slug)
      appendJsonl(join(ctx.directory, "writing", a.slug, "lint-history.jsonl"), {
        t: now(), file: relative(ctx.directory, p), genre: a.genre, verdict: r.verdict, ...r.metrics, flags: r.flags.length,
      })
    return render(r, relative(ctx.directory, p), a.max_flags ?? 30)
  },
})
