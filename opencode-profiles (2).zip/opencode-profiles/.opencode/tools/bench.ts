import { tool } from "@opencode-ai/plugin"
import { join } from "node:path"
import { appendJsonl, benchPath, checkerReport, loadConfig, loadOutcomes, now, project, readJsonl, report, reviewReport, route, similar, toCSV, writeText } from "../lib/core"

const TIERS = ["luna", "terra", "sol", "astra"] as const

export default tool({
  description:
    "Model benchmark (global, all projects). Research outcomes are logged by `ledger verdict`; use this for: report, review_report, similar, route, export (CSV), label (later evidence about a result), " +
    "outcome (work outside the ledger, e.g. type gap-resolution in reviews), and review events rv_check, rv_findings, rv_planted, rv_matches.",
  args: {
    action: tool.schema.enum(["report", "review_report", "similar", "route", "export", "label", "outcome", "rv_check", "rv_findings", "rv_planted", "rv_matches"]),
    review: tool.schema.string().optional().describe("review slug, for rv_* events"),
    task_id: tool.schema.string().optional(),
    title: tool.schema.string().optional().describe("task title, or query for `similar`"),
    type: tool.schema.string().optional(),
    tags: tool.schema.array(tool.schema.string()).optional(),
    difficulty: tool.schema.number().int().min(1).max(5).optional(),
    priority: tool.schema.number().int().min(1).max(3).optional(),
    depth: tool.schema.number().int().min(1).optional(),
    tier: tool.schema.enum(TIERS).optional(),
    attempt: tool.schema.number().int().min(0).optional(),
    verdict: tool.schema.enum(["pass", "pass_with_issues", "fail", "incomplete", "wrong_question"]).optional(),
    checker_tier: tool.schema.enum(TIERS).optional(),
    worker_session: tool.schema.string().optional(),
    checker_session: tool.schema.string().optional(),
    label: tool.schema.enum(["good", "bad"]).optional(),
    source: tool.schema.enum(["human", "replication", "downstream", "integration"]).optional(),
    check_id: tool.schema.string().optional().describe("rv_check: id of one checker run, e.g. S3"),
    role: tool.schema.string().optional().describe("rv_check: mapper|derive|sanity|lit|consistency|trace|resolve"),
    claims: tool.schema.array(tool.schema.string()).optional().describe("rv_check: claim ids the check examined"),
    items: tool.schema.array(tool.schema.object({
      id: tool.schema.string().describe("finding id or planted id"),
      check_id: tool.schema.string().optional(),
      tier: tool.schema.enum(TIERS).optional(),
      role: tool.schema.string().optional(),
      claim: tool.schema.string().optional(),
      kind: tool.schema.string().optional(),
      severity: tool.schema.string().optional(),
      status: tool.schema.enum(["confirmed", "downgraded", "rejected", "duplicate"]).optional().describe("rv_findings: fate after triage"),
      origin: tool.schema.enum(["WRITING", "RESEARCH", "CONFLICT", "UNTRACEABLE"]).optional(),
      trap: tool.schema.boolean().optional().describe("rv_planted: a step that is fine at physics level"),
      found: tool.schema.boolean().optional().describe("rv_matches: did this check find this planted item"),
    })).optional(),
    note: tool.schema.string().optional(),
  },
  async execute(a, ctx) {
    const dir = ctx.directory
    const cfg = loadConfig(dir)
    const t = now(), proj = project(dir)
    const needReview = () => (!a.review ? "ERROR: rv_* actions need `review`." : null)
    switch (a.action) {
      case "outcome":
        for (const k of ["task_id", "type", "difficulty", "tier", "verdict"] as const) if (a[k] === undefined) return `ERROR: outcome needs ${k}.`
        appendJsonl(benchPath(), { kind: "outcome", t, project: proj, task_id: a.task_id, title: a.title, type: a.type, tags: a.tags, difficulty: a.difficulty, priority: a.priority, tier: a.tier, attempt: a.attempt ?? 1, verdict: a.verdict, checker_tier: a.checker_tier, worker_session: a.worker_session, checker_session: a.checker_session, note: a.note })
        return `Logged ${a.task_id} ${a.type} ${a.tier}: ${a.verdict}.`
      case "label":
        if (!a.task_id || !a.label) return "ERROR: label needs task_id and label."
        appendJsonl(benchPath(), { kind: "label", t, project: proj, task_id: a.task_id, tier: a.tier, label: a.label, source: a.source ?? "human" })
        return `Labelled ${a.task_id} ${a.label}.`
      case "rv_check": {
        const e = needReview(); if (e) return e
        if (!a.check_id || !a.role || !a.tier) return "ERROR: rv_check needs check_id, role, tier."
        appendJsonl(benchPath(), { kind: "rv_check", t, review: a.review, check_id: a.check_id, role: a.role, tier: a.tier, claims: a.claims ?? [] })
        return `Check ${a.check_id} (${a.role}@${a.tier}) logged.`
      }
      case "rv_findings": case "rv_planted": case "rv_matches": {
        const e = needReview(); if (e) return e
        if (!a.items?.length) return "ERROR: needs `items`."
        const kind = a.action === "rv_findings" ? "rv_finding" : a.action === "rv_planted" ? "rv_planted" : "rv_match"
        for (const it of a.items) appendJsonl(benchPath(), { kind, t, review: a.review, ...(kind === "rv_finding" ? { finding_id: it.id } : { planted_id: it.id }), ...it })
        return `Logged ${a.items.length} ${kind} event(s).`
      }
      case "review_report":
        return reviewReport(readJsonl(benchPath()))
    }
    const outs = loadOutcomes(benchPath(), cfg)
    if (a.action === "route") {
      if (!a.type || !a.difficulty) return "ERROR: route needs type and difficulty."
      return JSON.stringify(route(outs, a.type, a.difficulty, cfg, { priority: a.priority, depth: a.depth }), null, 1)
    }
    if (a.action === "similar") {
      if (!a.title) return "ERROR: similar needs `title`."
      const r = similar(outs, a.title, a.type)
      return r.length ? JSON.stringify(r, null, 1) : "No similar past tasks yet."
    }
    if (a.action === "export") {
      writeText(join(dir, "research", "bench-export.csv"), toCSV(outs))
      return `Wrote ${outs.length} attempts to research/bench-export.csv.`
    }
    return report(outs, cfg) + checkerReport(readJsonl(benchPath()))
  },
})
