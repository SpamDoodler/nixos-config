// Keeps the research orchestrator on its procedure and records what each subagent really used.
//
// (An earlier version also injected a rule card into the system prompt. That duplicated the agents' own
// prompts, which opencode never compacts, so it was removed to keep the base context small.)
// 1. Procedure audit: when the research orchestrator is about to stop (and is not just waiting for its
//    own subagents), the ledger is audited. If something required is overdue, a short correction is
//    admitted as a synthetic message, so the orchestrator fixes it in the same execution. At most two
//    nudges per distinct problem, so the plugin can never loop.
// 2. Usage: when any r-, rv- or w- subagent session goes idle, its tokens, busy time (and USD, if your
//    provider reports any) are appended to the benchmark log; `bench report` turns tokens into allowance.
//
// Written against @opencode/plugin 2.3.2 (server plugin API). The `experimental.idle` hook is marked
// experimental upstream.
import { Plugin } from "@opencode/plugin"
import { appendJsonl, benchPath, ledgerPath, loadConfig, now, readJsonl } from "../lib/core"
import { audit, fold } from "../lib/ledger"

const TRACKED = /^(r|rv|w)-/

export default Plugin.define({
  id: "opencode-profiles",
  async setup(ctx) {
    const dir = String(ctx.location.directory)
    const nudges = new Map<string, { sig: string; n: number }>()

    await ctx.session.hook("experimental.idle", async (input) => {
      let info
      try {
        info = await ctx.session.get({ sessionID: input.sessionID })
      } catch {
        return
      }
      const agent = String(info.agent ?? "")

      if (info.parentID && TRACKED.test(agent)) {
        const busy = info.time.busy, idle = info.time.idle
        appendJsonl(benchPath(), {
          kind: "usage", t: now(), session: info.id, parent: info.parentID, agent,
          model: info.model ? `${info.model.providerID}/${info.model.id}${info.model.variant ? "#" + info.model.variant : ""}` : undefined,
          usd: Number(info.cost), tokens: info.tokens,
          seconds: busy && idle && idle > busy ? Math.round((idle - busy) / 1000) : undefined,
        })
        return
      }

      if (agent !== "research") return
      // Waiting for its own subagents is normal: their reports will wake the session.
      if (input.background.some((b) => b.kind === "subagent" && b.sessionID === input.sessionID)) return
      let must: string[] = []
      try {
        must = audit(fold(readJsonl(ledgerPath(dir))), loadConfig(dir)).must
      } catch {
        return
      }
      if (!must.length) {
        nudges.delete(input.sessionID)
        return
      }
      const sig = must.join("|")
      const prev = nudges.get(input.sessionID)
      const n = prev && prev.sig === sig ? prev.n + 1 : 1
      if (n > 2) return
      nudges.set(input.sessionID, { sig, n })
      await ctx.session.synthetic({
        sessionID: input.sessionID,
        description: "procedure check",
        text: "PROCEDURE CHECK before you stop. The ledger shows required steps that are overdue:\n" + must.map((m) => "- " + m).join("\n") +
          "\nDo them now, or record with the ledger why one does not apply.",
      })
    })
  },
})
