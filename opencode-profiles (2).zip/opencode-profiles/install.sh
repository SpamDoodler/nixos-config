#!/usr/bin/env bash
# Install the research and review profiles into an opencode config directory.
#
#   ./install.sh --target project --dir ~/work/myproject \
#       --luna provider/luna-id --terra provider/terra-id --sol provider/sol-id --astra provider/astra-id
#   ./install.sh --target global  --luna ... --terra ... --sol ... --astra ...
#
# Model ids are written into the agent files (they replace @LUNA@ etc.). Existing files are
# skipped unless --force is given. Nothing outside the target config directory is touched.
set -euo pipefail

target=""; dir="$PWD"; force=0; luna=""; terra=""; sol=""; astra=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --target) target="$2"; shift 2;;
    --dir)    dir="$2"; shift 2;;
    --luna)   luna="$2"; shift 2;;
    --terra)  terra="$2"; shift 2;;
    --sol)    sol="$2"; shift 2;;
    --astra)  astra="$2"; shift 2;;
    --force)  force=1; shift;;
    -h|--help) sed -n '2,10p' "$0"; exit 0;;
    *) echo "unknown option: $1" >&2; exit 2;;
  esac
done
[[ "$target" == "project" || "$target" == "global" ]] || { echo "--target project|global is required" >&2; exit 2; }
for v in luna terra sol astra; do [[ -n "${!v}" ]] || { echo "--$v MODEL_ID is required (e.g. provider/model)" >&2; exit 2; }; done

src="$(cd "$(dirname "$0")" && pwd)/.opencode"
if [[ "$target" == "project" ]]; then dest="$(cd "$dir" && pwd)/.opencode"; else dest="${XDG_CONFIG_HOME:-$HOME/.config}/opencode"; fi
kit="$dest/kit"
mkdir -p "$dest"

copied=0; skipped=0
while IFS= read -r -d '' f; do
  rel="${f#"$src"/}"
  out="$dest/$rel"
  if [[ -e "$out" && $force -eq 0 ]]; then echo "skip (exists): $out"; skipped=$((skipped+1)); continue; fi
  if [[ "$rel" == "package.json" && -e "$out" ]]; then echo "skip (exists): $out"; skipped=$((skipped+1)); continue; fi
  mkdir -p "$(dirname "$out")"
  sed -e "s|@LUNA@|$luna|g" -e "s|@TERRA@|$terra|g" -e "s|@SOL@|$sol|g" -e "s|@ASTRA@|$astra|g" -e "s|@KIT@|$kit|g" "$f" > "$out"
  copied=$((copied+1))
done < <(find "$src" -type f ! -path '*/node_modules/*' -print0)

echo
echo "Installed $copied files to $dest ($skipped skipped)."
echo
echo "Next steps:"
echo "  1. Edit $kit/tiers.json: relative cost and latency of one attempt per tier."
echo "  2. If $dest/package.json already existed, make sure it lists @opencode-ai/plugin."
echo "  3. Merge what you want from opencode.example.jsonc (instructions, compaction model, references)."
echo "  4. Restart opencode (or run: opencode reload) and run the smoke tests in the guide."
