# opencode profiles: research, review, write

Three primary agents for opencode 2.3, with their subagents, skills and tools.

- `research`: turns an abstract goal into concrete formulations and a task graph, runs cheap subagents in parallel, verifies results at a level matched to their importance, benchmarks the models, guards against solving the wrong problem. Works with `/goal`.
- `review`: maps a document's claims, checks the load-bearing ones independently (including blind re-derivation), reports localised findings at physics-level or math-level rigor.
- `write`: turns research and review output into papers, lecture notes or reports: evidence-calibrated claims, motivated structure, genre-specific rigor and detail, cold-reader and fidelity checks, a deterministic style check.

The rationale and the implementation guide are in the accompanying doc.

## Install

```bash
./install.sh --target project --dir ~/work/myproject \
  --luna PROVIDER/LUNA_ID --terra PROVIDER/TERRA_ID --sol PROVIDER/SOL_ID --astra PROVIDER/ASTRA_ID
```

Model ids may carry a variant (`provider/model#high`). `opencode models` lists them. Then edit `.opencode/kit/tiers.json`, and merge what you want from `opencode.example.jsonc` into your config.

## Use

| You want | Do |
| --- | --- |
| Autonomous research | `research` agent, `/brief <idea>`, then paste the `/goal ...` line it prints |
| Interactive research | `/research <question>` |
| A review | `/review <path> depth=standard rigor=P` |
| Benchmark the reviewers | `/review-bench <trusted document>` |
| A paper, notes or report | `/write-brief <slug> <description>`, then `/write <slug>` or the printed `/goal` line |
| Benchmark | `/bench`, `/bench label <task> good|bad`, or ask for `bench export` (CSV) |
| Teach the reviewer / writer | `/calibrate <note>`, `/style-note <note>` |

## Installed into `.opencode/` (or `~/.config/opencode/`)

```
agents/   research, review, write                     (primary, sol)
          r-strategist (astra), r-recon-ws, r-recon-lit, r-worker-luna|terra|sol|astra,
          r-verifier-t (terra), r-verifier-s (sol), r-verifier-a (astra), r-skeptic, r-redteam
          rv-mapper, rv-derive, rv-sanity, rv-lit, rv-consistency, rv-arbiter (astra),
          rv-trace, rv-probe-luna|terra|sol, rv-planter, rv-scorer
          w-digest, w-architect (astra), w-drafter, w-figure, w-reader, w-fidelity, w-editor
commands/ brief, research, review, review-bench, bench, calibrate, write-brief, write, style-note
skills/   rigor, research-procedure, research-planning, research-verification, research-goal,
          review-procedure, review-roles, writing-procedure, writing-style, writing-genres
tools/    ledger.ts (state machine), bench.ts, stylecheck.ts
plugins/  profiles.ts   (procedure audit before the orchestrator stops; token logging for the benchmark)
lib/      core.ts, ledger.ts, style.ts   (shared logic; not tools)
kit/      tiers.json          (costs and latencies used by the router)
```

## Written into your workspace while running

```
research/  GOAL.md, FRAMING.md, PLAN.md, CONVENTIONS.md, CLAIMS.md, STATUS.md, LEDGER.md, ledger.jsonl, ...
review/<slug>/   claims.md, plan.md, checks/, REPORT.md
writing/<slug>/  BRIEF.md, EVIDENCE.md, STYLE.md, STORY.md, draft.tex|md, figures/, reviews/, STATUS.md, lint-history.jsonl
~/.local/share/opencode-bench/events.jsonl   (global benchmark; override with OPENCODE_BENCH_DIR)
```

## Tested

YAML frontmatter of all agents, commands and skills; cross-references between agents, skills and tools; the three tools under Bun (simulated research session, astra gate, routing, report, style checks on sample texts); strict TypeScript; the installer. Not tested inside a live opencode session: see the smoke tests in the guide.
